//Desenvolvedor Jonas gomes versão 1.0
function objsF(said){

	//Ativa o modo edição
	var objsai = document.querySelector(said);
	objsai.designMode="On";

	//Função para eventos e saida de objeto e alteração de fonts
	this.fonte = function(obj){
		document.querySelector(obj.font).addEventListener(obj.efont,function(){
			document.execCommand("fontName",true,this.value);
		});
	}

	//Função para alterar o tamanho da fonte
	this.fonteTamanho = function(obj){
		document.querySelector(obj.font).addEventListener(obj.efont,function(){
			document.execCommand("fontSize",false,"7");
			var p = document.querySelectorAll("font");
			for(var i = 0; i < p.length; i++ ){
				if( p[i].size == "7" ){
					p[i].removeAttribute("size");
					p[i].style.fontSize = this.value;
				}
			}
		});

	} 

	//Função para eventos de negrito, italico e sublinhado
	this.fNis = function(obj){
		document.querySelector(obj.font).addEventListener(obj.efont,function(){
			document.execCommand(obj.nis);
			//objsai.focus();
		});
	}

	//Função para alinhar texto
	this.fAlinhar = function(obj){
		document.querySelector(obj.font).addEventListener(obj.efont,function(){
			document.execCommand(obj.align,false,"");
		});
	}

	//Função para criar link
	this.fLink = function(obj,exibir){
		var _div = document.createElement("div");
		document.querySelector(obj.font).addEventListener(obj.efont,function(){
			if( exibir == true ){
				var pt = prompt("Insira o link desejado: ","");
				var lk = document.execCommand(obj.com,true,pt);
				lk.target="_blank";
			}
			document.execCommand(obj.com,true,pt);
		});
	}

	//Função para criar uma imagem
	this.fImagem = function(obj){
		document.querySelector(obj.font).addEventListener(obj.efont,function(){
			var pt = prompt("Insira o link da imagem: ","");
			document.execCommand("insertImage",true,pt);
		});
	}

	//Função para criar um vídeo obs: só aceita vídeo do youtube.
	this.fVideo = function(obj){
		document.querySelector(obj.font).addEventListener(obj.efont,function(){
			var pt = prompt("Insira o link do vídeo: ","");
			pt     = pt.slice(32); 
			document.execCommand("insertHTML",true,'<iframe width="560" height="315" src="https://www.youtube.com/embed/'+pt+'" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>');
		});
	}

	//Função para criar o h1 ao h3
	this.fH = function(obj){
		document.querySelector(obj.font).addEventListener(obj.efont,function(){
			document.execCommand("formatBlock",true,obj.hs);
		});
	}

}
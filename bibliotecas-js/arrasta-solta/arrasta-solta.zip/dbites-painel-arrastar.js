function objMove(){

    var idNome = null;

    //Retorna ao valor padrao
    this.iniPadrao = function(event){
        event.preventDefault();
    }

    //Inicia o processo de arrastar
    this.iniMove   = function(idobj,event){
        idNome = idobj;
        event.dataTransfer.setData(idNome,event.target.id);
    } 

    //Inicia o processo de soltar
    this.iniSoltar = function(idobj,event){
        event.preventDefault();
        var objId        = document.createElement(idobj.nome);
        objId.id         = idNome; 
        objId.className  = idNome;
        var t = event.dataTransfer.getData(idNome);
        //objId.className  = ;
        event.target.appendChild(objId);

        var mh    = document.querySelectorAll(".dbites-menu-h");
        var menuh = ['home','contato','empresa'];
        mh[mh.length-1].innerHTML = "<span>Logo</span>";
        for(var i = 0; i < menuh.length; i++){
            mh[mh.length-1].innerHTML += "<div>"+menuh[i]+"</div>";
        }
    
    }
    
}
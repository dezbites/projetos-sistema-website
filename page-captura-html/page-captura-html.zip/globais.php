<?php

define("DB_HOSTNAME", "localhost");
define("DB_USER", "valadaresturismo_dezbites_clientes");
define("DB_PASS", "ste@12345");
define("DB_NOME", "valadaresturismo_dezbites_clientes");

?>
